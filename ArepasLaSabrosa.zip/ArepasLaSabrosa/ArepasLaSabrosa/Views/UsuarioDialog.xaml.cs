using System;
using System.Windows;
using System.Windows.Controls;
using ArepasLaSabrosa.Models;
using ArepasLaSabrosa.Services;

namespace ArepasLaSabrosa.Views
{
    public partial class UsuarioDialog : Window
    {
        private readonly bool _esEdicion;
        private readonly Usuario? _usuarioAEditar;

        public UsuarioDialog()
        {
            InitializeComponent();
            _esEdicion = false;
            CmbRol.SelectedIndex = 1; // Cajero por defecto
            ConfigurarInterfaz();
        }

        public UsuarioDialog(Usuario usuario) : this()
        {
            _esEdicion = true;
            _usuarioAEditar = usuario;
            CargarDatosUsuario();
            ConfigurarInterfaz();
        }

        private void ConfigurarInterfaz()
        {
            if (_esEdicion)
            {
                Title = "Editar Usuario";
                LblTitulo.Text = "✏️ Editar Usuario";
                BtnAccion.Content = "✏️ Guardar Cambios";
                BtnAccion.Background = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(255, 193, 7)); // Yellow
                LblPassword.Content = "Nueva Contraseña (opcional):";
                PanelEstado.Visibility = Visibility.Visible;
            }
            else
            {
                Title = "Crear Usuario";
                LblTitulo.Text = "👤 Crear Nuevo Usuario";
                BtnAccion.Content = "👤 Crear Usuario";
                PanelEstado.Visibility = Visibility.Collapsed;
            }
        }

        private void CargarDatosUsuario()
        {
            if (_usuarioAEditar == null) return;

            TxtUsuario.Text = _usuarioAEditar.NombreUsuario;
            ChkEstaActivo.IsChecked = _usuarioAEditar.EstaActivo;

            // Seleccionar el rol correspondiente
            foreach (ComboBoxItem item in CmbRol.Items)
            {
                if (item.Tag?.ToString() == _usuarioAEditar.Rol.ToString())
                {
                    CmbRol.SelectedItem = item;
                    break;
                }
            }
        }

        private void BtnAccion_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidarDatos())
                return;

            try
            {
                var nombreUsuario = TxtUsuario.Text.Trim();
                var password = TxtPassword.Password;
                var rolSeleccionado = ((ComboBoxItem)CmbRol.SelectedItem).Tag?.ToString() ?? "";
                
                if (!Enum.TryParse<RolUsuario>(rolSeleccionado, out var rol))
                {
                    MessageBox.Show("Seleccione un rol válido.", "Error", 
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                bool operacionExitosa;

                if (_esEdicion)
                {
                    var estaActivo = ChkEstaActivo.IsChecked ?? true;
                    operacionExitosa = ServicioAutenticacion.EditarUsuario(
                        _usuarioAEditar!.Id, nombreUsuario, password, rol, estaActivo);
                }
                else
                {
                    operacionExitosa = ServicioAutenticacion.CrearUsuario(nombreUsuario, password, rol);
                }

                if (operacionExitosa)
                {
                    MessageBox.Show(_esEdicion ? "Usuario editado exitosamente." : "Usuario creado exitosamente.", 
                        "Éxito", MessageBoxButton.OK, MessageBoxImage.Information);
                    this.DialogResult = true;
                    this.Close();
                }
                else
                {
                    MessageBox.Show(_esEdicion ? "Error al editar el usuario. Verifique que el nombre de usuario no esté en uso." : "El nombre de usuario ya existe.", 
                        "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                    TxtUsuario.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al {(_esEdicion ? "editar" : "crear")} el usuario: {ex.Message}", "Error", 
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnCancelar_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }

        private bool ValidarDatos()
        {
            if (string.IsNullOrWhiteSpace(TxtUsuario.Text))
            {
                MessageBox.Show("Ingrese el nombre de usuario.", "Validación", 
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtUsuario.Focus();
                return false;
            }

            // En modo edición, la contraseña es opcional
            if (!_esEdicion && string.IsNullOrWhiteSpace(TxtPassword.Password))
            {
                MessageBox.Show("Ingrese la contraseña.", "Validación", 
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtPassword.Focus();
                return false;
            }

            // Si se ingresó contraseña, validar longitud
            if (!string.IsNullOrWhiteSpace(TxtPassword.Password) && TxtPassword.Password.Length < 3)
            {
                MessageBox.Show("La contraseña debe tener al menos 3 caracteres.", "Validación", 
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtPassword.Focus();
                return false;
            }

            if (CmbRol.SelectedItem == null)
            {
                MessageBox.Show("Seleccione un rol.", "Validación", 
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                CmbRol.Focus();
                return false;
            }

            return true;
        }
    }
}