using System;
using System.Windows;
using ArepasLaSabrosa.Services;

namespace ArepasLaSabrosa.Views
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            try
            {
                InitializeComponent();
                TxtUsuario.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al inicializar LoginWindow: {ex.Message}\n\nDetalles: {ex}", 
                    "Error de Inicio", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            LblError.Visibility = Visibility.Collapsed;

            if (string.IsNullOrWhiteSpace(TxtUsuario.Text))
            {
                MostrarError("Por favor ingrese un usuario");
                return;
            }

            if (TxtUsuario.Text.ToLower() != "selfcheckout" && string.IsNullOrWhiteSpace(TxtPassword.Password))
            {
                MostrarError("Por favor ingrese la contraseña");
                return;
            }

            bool loginExitoso = ServicioAutenticacion.IniciarSesion(TxtUsuario.Text, TxtPassword.Password);

            if (loginExitoso)
            {
                var mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
            }
            else
            {
                MostrarError("Usuario o contraseña incorrectos");
                TxtPassword.Clear();
                TxtUsuario.Focus();
            }
        }

        private void BtnSelfCheckout_Click(object sender, RoutedEventArgs e)
        {
            bool loginExitoso = ServicioAutenticacion.IniciarSesion("selfcheckout", "");

            if (loginExitoso)
            {
                var mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
            }
            else
            {
                MostrarError("Error al acceder al modo Self-Checkout");
            }
        }

        private void MostrarError(string mensaje)
        {
            LblError.Text = mensaje;
            LblError.Visibility = Visibility.Visible;
        }

        private void Window_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                BtnLogin_Click(sender, e);
            }
        }
    }
}