using System;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Input;
using ArepasLaSabrosa.Models;

namespace ArepasLaSabrosa.Views
{
    public partial class ProductoDialog : Window
    {
        public Producto Producto { get; private set; } = null!;
        private bool esEdicion;

        public ProductoDialog(Producto? producto = null)
        {
            InitializeComponent();
            ConfigurarValidaciones();
            
            if (producto != null)
            {
                esEdicion = true;
                LblTitulo.Text = "Editar Producto";
                CargarDatosProducto(producto);
            }
            else
            {
                esEdicion = false;
                LblTitulo.Text = "Agregar Producto";
                Producto = new Producto();
            }
        }

        private void ConfigurarValidaciones()
        {
            // Configurar validaciones para campos numéricos
            TxtPrecio.PreviewTextInput += TxtPrecio_PreviewTextInput;
            TxtStock.PreviewTextInput += TxtStock_PreviewTextInput;
            
            // Evitar pegar texto no válido
            TxtPrecio.CommandBindings.Add(new CommandBinding(ApplicationCommands.Paste, null, CannotPaste));
            TxtStock.CommandBindings.Add(new CommandBinding(ApplicationCommands.Paste, null, CannotPaste));
        }

        private void TxtPrecio_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Permitir números, punto decimal y coma decimal
            Regex regex = new Regex(@"^[0-9.,]+$");
            e.Handled = !regex.IsMatch(e.Text);
        }

        private void TxtStock_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Solo números enteros
            Regex regex = new Regex(@"^[0-9]+$");
            e.Handled = !regex.IsMatch(e.Text);
        }

        private void CannotPaste(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = false;
            e.Handled = true;
        }

        private void CargarDatosProducto(Producto producto)
        {
            Producto = new Producto
            {
                Id = producto.Id,
                Nombre = producto.Nombre,
                Precio = producto.Precio,
                Stock = producto.Stock,
                Categoria = producto.Categoria,
                Descripcion = producto.Descripcion
            };

            TxtNombre.Text = producto.Nombre;
            TxtPrecio.Text = producto.Precio.ToString();
            TxtStock.Text = producto.Stock.ToString();
            CmbCategoria.Text = producto.Categoria;
            TxtDescripcion.Text = producto.Descripcion;
        }

        private void BtnGuardar_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidarDatos())
                return;

            try
            {
                Producto.Nombre = TxtNombre.Text.Trim();
                Producto.Precio = decimal.Parse(TxtPrecio.Text);
                Producto.Stock = int.Parse(TxtStock.Text);
                Producto.Categoria = CmbCategoria.Text.Trim();
                Producto.Descripcion = TxtDescripcion.Text.Trim();

                this.DialogResult = true;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al procesar los datos: {ex.Message}", "Error", 
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnCancelar_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }

        private bool ValidarDatos()
        {
            if (string.IsNullOrWhiteSpace(TxtNombre.Text))
            {
                MessageBox.Show("Ingrese el nombre del producto.", "Validación", 
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtNombre.Focus();
                return false;
            }

            if (!decimal.TryParse(TxtPrecio.Text, out decimal precio) || precio <= 0)
            {
                MessageBox.Show("Ingrese un precio válido mayor a 0.", "Validación", 
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtPrecio.Focus();
                return false;
            }

            if (!int.TryParse(TxtStock.Text, out int stock) || stock < 0)
            {
                MessageBox.Show("Ingrese un stock válido (0 o mayor).", "Validación", 
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtStock.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(CmbCategoria.Text))
            {
                MessageBox.Show("Seleccione o ingrese una categoría.", "Validación", 
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                CmbCategoria.Focus();
                return false;
            }

            return true;
        }
    }
}