using System;
using System.IO;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using ArepasLaSabrosa.Models;
using ArepasLaSabrosa.Services;

namespace ArepasLaSabrosa.Views
{
    // Ventana principal del sistema POS
    public partial class MainWindow : Window
    {
        // Variables principales del sistema
        private Venta ventaActual = null!;                    // Venta que se está procesando actualmente
        private ObservableCollection<ItemVenta> itemsCarrito = null!; // Items en el carrito
        private DispatcherTimer timer = null!;               // Timer para actualizar fecha/hora

        // Constructor de la ventana principal
        public MainWindow()
        {
            InitializeComponent();    // Inicializa los controles de la UI
            InicializarVentana();     // Configura el estado inicial
            ConfigurarEventos();      // Configura eventos
            CargarDatos();           // Carga datos iniciales
        }

        // Configura el estado inicial de la ventana
        private void InicializarVentana()
        {
            // Crea una nueva venta vacía
            ventaActual = ServicioVentas.CrearNuevaVenta();
            // Inicializa la colección del carrito
            itemsCarrito = new ObservableCollection<ItemVenta>();
            // Conecta el carrito con el DataGrid de la UI
            GridCarrito.ItemsSource = itemsCarrito;

            // Configura timer para mostrar fecha y hora actual
            timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(1) // Actualiza cada segundo
            };
            timer.Tick += Timer_Tick;
            timer.Start();

            // Configura la interfaz según el rol del usuario
            ActualizarInterfazSegunRol();
            // Carga estadísticas iniciales
            ActualizarEstadisticas();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            LblFechaHora.Text = DateTime.Now.ToString("dddd, dd MMMM yyyy - HH:mm:ss");
        }

        private void ConfigurarEventos()
        {
            this.Closing += MainWindow_Closing;
            itemsCarrito.CollectionChanged += ItemsCarrito_CollectionChanged;
        }

        private void ActualizarInterfazSegunRol()
        {
            var usuario = ServicioAutenticacion.UsuarioActual;
            if (usuario == null) return;

            LblUsuarioActual.Text = $"Usuario: {usuario.NombreUsuario} | Rol: {Usuario.ObtenerDescripcionRol(usuario.Rol)}";

            // Configurar visibilidad de tabs según rol
            TabVentas.Visibility = ServicioAutenticacion.PuedeAccederVentas() ? Visibility.Visible : Visibility.Collapsed;
            TabInventario.Visibility = (ServicioAutenticacion.PuedeGestionarInventario() || ServicioAutenticacion.PuedeSoloVerInventario()) ? Visibility.Visible : Visibility.Collapsed;
            TabEstadisticas.Visibility = ServicioAutenticacion.PuedeVerEstadisticas() ? Visibility.Visible : Visibility.Collapsed;
            TabUsuarios.Visibility = ServicioAutenticacion.PuedeGestionarUsuarios() ? Visibility.Visible : Visibility.Collapsed;

            // Para usuarios que solo pueden ver inventario, deshabilitar controles
            if (ServicioAutenticacion.PuedeSoloVerInventario())
            {
                PanelControlesInventario.Visibility = Visibility.Collapsed;
                GridInventario.IsReadOnly = true;
            }

            // Si es self-checkout, simplificar interfaz
            if (ServicioAutenticacion.EsSelfCheckout())
            {
                this.Title = "🛒 Self-Checkout - Arepas La Sabrosa";
            }

            // Configurar tab inicial según rol
            ConfigurarTabInicial();
        }

        private void ConfigurarTabInicial()
        {
            var usuario = ServicioAutenticacion.UsuarioActual;
            if (usuario == null) return;

            // Para usuario de inventario, abrir directamente la pestaña de inventario
            if (usuario.Rol == Models.RolUsuario.UsuarioInventario)
            {
                TabsPrincipales.SelectedItem = TabInventario;
            }
            // Para otros roles, mantener comportamiento por defecto (primera pestaña visible)
            else
            {
                // Buscar la primera pestaña visible
                foreach (TabItem tab in TabsPrincipales.Items)
                {
                    if (tab.Visibility == Visibility.Visible)
                    {
                        TabsPrincipales.SelectedItem = tab;
                        break;
                    }
                }
            }
        }

        private void CargarDatos()
        {
            CargarCategorias();
            CargarProductos();
            CargarInventario();
            CargarUsuarios();
            CargarRecibos();
        }

        private void CargarCategorias()
        {
            var categorias = ServicioInventario.ObtenerCategorias();
            categorias.Insert(0, "Todas");
            CmbCategorias.ItemsSource = categorias;
            CmbCategorias.SelectedIndex = 0;
        }

        private void CargarProductos(string? categoriaFiltro = null)
        {
            PanelProductos.Children.Clear();

            var productos = string.IsNullOrEmpty(categoriaFiltro) || categoriaFiltro == "Todas"
                ? ServicioInventario.Productos
                : ServicioInventario.FiltrarPorCategoria(categoriaFiltro);

            foreach (var producto in productos.Where(p => p.Stock > 0))
            {
                var tarjetaProducto = CrearTarjetaProducto(producto);
                PanelProductos.Children.Add(tarjetaProducto);
            }
        }

        private Border CrearTarjetaProducto(Producto producto)
        {
            var border = new Border
            {
                Width = 200,
                Height = 150,
                Margin = new Thickness(10),
                Background = new SolidColorBrush(Colors.White),
                BorderBrush = new SolidColorBrush(Color.FromRgb(222, 184, 135)),
                BorderThickness = new Thickness(2),
                CornerRadius = new CornerRadius(10),
                Cursor = System.Windows.Input.Cursors.Hand
            };

            var grid = new Grid();
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            // Nombre del producto
            var txtNombre = new TextBlock
            {
                Text = producto.Nombre,
                FontWeight = FontWeights.Bold,
                FontSize = 14,
                TextAlignment = TextAlignment.Center,
                Margin = new Thickness(10, 10, 10, 5),
                TextWrapping = TextWrapping.Wrap,
                Foreground = new SolidColorBrush(Color.FromRgb(139, 69, 19))
            };
            Grid.SetRow(txtNombre, 0);

            // Precio
            var txtPrecio = new TextBlock
            {
                Text = $"${producto.Precio:N0}",
                FontWeight = FontWeights.Bold,
                FontSize = 16,
                TextAlignment = TextAlignment.Center,
                Foreground = new SolidColorBrush(Color.FromRgb(40, 167, 69)),
                Margin = new Thickness(0, 5, 0, 5)
            };
            Grid.SetRow(txtPrecio, 1);

            // Stock
            var txtStock = new TextBlock
            {
                Text = $"Stock: {producto.Stock}",
                FontSize = 10,
                TextAlignment = TextAlignment.Center,
                Foreground = producto.Stock <= 5 ? new SolidColorBrush(Colors.Red) : new SolidColorBrush(Colors.Gray),
                Margin = new Thickness(0, 2, 0, 2)
            };
            Grid.SetRow(txtStock, 2);

            // Categoría
            var txtCategoria = new TextBlock
            {
                Text = producto.Categoria,
                FontSize = 10,
                FontStyle = FontStyles.Italic,
                TextAlignment = TextAlignment.Center,
                Foreground = new SolidColorBrush(Color.FromRgb(108, 117, 125)),
                Margin = new Thickness(0, 2, 0, 10)
            };
            Grid.SetRow(txtCategoria, 3);

            grid.Children.Add(txtNombre);
            grid.Children.Add(txtPrecio);
            grid.Children.Add(txtStock);
            grid.Children.Add(txtCategoria);
            border.Child = grid;

            // Evento clic
            border.MouseLeftButtonUp += (s, e) => AgregarProductoAlCarrito(producto);

            // Efecto hover
            border.MouseEnter += (s, e) => border.Background = new SolidColorBrush(Color.FromRgb(248, 249, 250));
            border.MouseLeave += (s, e) => border.Background = new SolidColorBrush(Colors.White);

            return border;
        }

        // Método que se ejecuta cuando se hace clic en un producto
        private void AgregarProductoAlCarrito(Producto producto)
        {
            try
            {
            // Verifica que haya stock disponible
            if (producto.Stock <= 0)
            {
                MessageBox.Show($"El producto {producto.Nombre} no tiene stock disponible.",
                    "Stock Insuficiente", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Muestra diálogo para que el usuario seleccione la cantidad
            var cantidadDialog = new CantidadDialog(producto);
            if (cantidadDialog.ShowDialog() == true)
            {
                int cantidad = cantidadDialog.Cantidad;

                // Verificación adicional de stock por seguridad
                if (cantidad > producto.Stock)
                {
                    MessageBox.Show($"La cantidad solicitada ({cantidad}) excede el stock disponible ({producto.Stock}).",
                        "Stock Insuficiente", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Actualiza el stock inmediatamente (reserva el producto)
                ServicioInventario.ActualizarStock(producto.Id, cantidad);

                // Verifica si el producto ya está en el carrito
                var itemExistente = itemsCarrito.FirstOrDefault(i => i.Producto.Id == producto.Id);
                if (itemExistente != null)
                {
                    // Si ya existe, aumenta la cantidad
                    itemExistente.Cantidad += cantidad;
                    // Actualiza el total del item en la UI
                    itemExistente.NotifyPropertyChanged(nameof(itemExistente.Total));
                }
                else
                {
                    // Si no existe, agrega un nuevo item al carrito
                    itemsCarrito.Add(new ItemVenta(producto, cantidad));
                }

                // Agrega el producto a la venta actual
                ventaActual.AgregarProducto(producto, cantidad);
                // Actualiza los totales mostrados en pantalla
                ActualizarTotales();

                // Recarga la vista de productos para mostrar el stock actualizado
                CargarProductos(CmbCategorias.SelectedItem?.ToString());
            }
            }
            catch (Exception ex)
            {
                // Registrar excepción en archivo y mostrar detalle para depuración
                try
                {
                    var logDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ArepasLaSabrosa");
                    Directory.CreateDirectory(logDir);
                    var logPath = Path.Combine(logDir, "error_log.txt");
                    File.AppendAllText(logPath, DateTime.Now + " - Excepción en AgregarProductoAlCarrito:\n" + ex + "\n\n");
                }
                catch { }

                MessageBox.Show($"Excepción al añadir producto al carrito:\n{ex.Message}\n\nSe registró el detalle en el archivo de log.", "Error inesperado",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CargarInventario()
        {
            GridInventario.ItemsSource = ServicioInventario.Productos;
        }

        private void CargarUsuarios()
        {
            if (ServicioAutenticacion.PuedeGestionarUsuarios())
            {
                GridUsuarios.ItemsSource = ServicioAutenticacion.ObtenerUsuarios();
            }
        }

        private void CargarRecibos()
        {
            if (ServicioAutenticacion.PuedeVerEstadisticas())
            {
                GridRecibos.ItemsSource = ServicioVentas.HistorialVentas;
            }
        }

        private void ActualizarTotales()
        {
            var subtotal = itemsCarrito.Sum(i => i.Total);
            var iva = subtotal * 0.19m;
            var total = subtotal + iva;

            LblSubtotal.Text = $"Subtotal: ${subtotal:N0}";
            LblIVA.Text = $"IVA (19%): ${iva:N0}";
            LblTotal.Text = $"TOTAL: ${total:N0}";

            BtnProcesarVenta.IsEnabled = itemsCarrito.Count > 0;
        }

        private void ActualizarEstadisticas()
        {
            if (!ServicioAutenticacion.PuedeVerEstadisticas()) return;

            var ventasHoy = ServicioVentas.ObtenerTotalVentasDia(DateTime.Today);
            var cantidadVentas = ServicioVentas.ObtenerCantidadVentasDia(DateTime.Today);
            var totalProductos = ServicioInventario.Productos.Count;
            var stockCritico = ServicioInventario.Productos.Count(p => p.Stock <= 5);
            var productosMasVendidos = ServicioVentas.ObtenerProductosMasVendidos(1);
            var promedioVenta = ServicioVentas.HistorialVentas.Count > 0 ? 
                ServicioVentas.HistorialVentas.Average(v => v.Total) : 0;

            LblVentasHoy.Text = $"${ventasHoy:N0}";
            LblCantidadVentas.Text = cantidadVentas.ToString();
            LblTotalProductos.Text = totalProductos.ToString();
            LblStockCritico.Text = stockCritico.ToString();
            LblProductoTop.Text = productosMasVendidos.FirstOrDefault().Producto ?? "N/A";
            LblPromedioVenta.Text = $"${promedioVenta:N0}";
        }

        // Event Handlers
        private void CmbCategorias_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbCategorias.SelectedItem != null)
            {
                CargarProductos(CmbCategorias.SelectedItem?.ToString());
            }
        }

        private void BtnQuitarItem_Click(object sender, RoutedEventArgs e)
        {
            var itemSeleccionado = GridCarrito.SelectedItem as ItemVenta;
            if (itemSeleccionado == null)
            {
                MessageBox.Show("Seleccione un producto del carrito.", "Información",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            // Restaurar stock inmediatamente
            ServicioInventario.RestaurarStock(itemSeleccionado.Producto.Id, 1);

            // Quitar del carrito
            if (itemSeleccionado.Cantidad > 1)
            {
                itemSeleccionado.Cantidad--;
            }
            else
            {
                itemsCarrito.Remove(itemSeleccionado);
            }

            ventaActual.QuitarProducto(itemSeleccionado.Producto.Id, 1);
            ActualizarTotales();

            // Recargar productos para mostrar stock actualizado
            CargarProductos(CmbCategorias.SelectedItem?.ToString());
        }

        private void BtnLimpiarCarrito_Click(object sender, RoutedEventArgs e)
        {
            if (itemsCarrito.Count == 0) return;

            var resultado = MessageBox.Show("¿Está seguro de que desea limpiar el carrito?",
                "Confirmar", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                // Restaurar todo el stock
                foreach (var item in itemsCarrito.ToList())
                {
                    ServicioInventario.RestaurarStock(item.Producto.Id, item.Cantidad);
                }

                itemsCarrito.Clear();
                ventaActual.LimpiarCarrito();
                ActualizarTotales();

                // Recargar productos
                CargarProductos(CmbCategorias.SelectedItem?.ToString());
            }
        }

        private void BtnProcesarVenta_Click(object sender, RoutedEventArgs e)
        {
            if (itemsCarrito.Count == 0)
            {
                MessageBox.Show("El carrito está vacío.", "Información",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            try
            {
                // Copiar items al objeto venta
                ventaActual.Items.Clear();
                foreach (var item in itemsCarrito)
                {
                    ventaActual.Items.Add(new ItemVenta(item.Producto, item.Cantidad));
                }

                // Calcular total
                var totalVenta = ventaActual.Total;

                // Mostrar diálogo de método de pago
                var metodoPagoDialog = new MetodoPagoDialog(totalVenta);
                if (metodoPagoDialog.ShowDialog() == true)
                {
                    // Procesar venta
                    bool ventaProcesada = ServicioVentas.ProcesarVenta(ventaActual);

                    if (ventaProcesada)
                    {
                        // Generar recibo con información del pago
                        var recibo = GenerarReciboConPago(ventaActual, metodoPagoDialog);
                        MessageBox.Show(recibo, "Recibo de Venta", MessageBoxButton.OK, MessageBoxImage.Information);

                        // Generar PDF
                        try
                        {
                            var rutaPDF = ServicioVentas.GenerarReciboPDF(ventaActual);
                            var resultado = MessageBox.Show($"Venta procesada exitosamente.\n\n¿Desea abrir el recibo PDF?\n\nArchivo: {rutaPDF}",
                                "Venta Exitosa", MessageBoxButton.YesNo, MessageBoxImage.Information);

                            if (resultado == MessageBoxResult.Yes)
                            {
                                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(rutaPDF) { UseShellExecute = true });
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Error al generar PDF: {ex.Message}", "Error PDF",
                                MessageBoxButton.OK, MessageBoxImage.Warning);
                        }

                        // Limpiar carrito y crear nueva venta
                        itemsCarrito.Clear();
                        ventaActual = ServicioVentas.CrearNuevaVenta();
                        ActualizarTotales();
                        ActualizarEstadisticas();
                        CargarRecibos();
                    }
                    else
                    {
                        MessageBox.Show("Error al procesar la venta.", "Error",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                else
                {
                    // El usuario canceló el pago, mantener el carrito
                    MessageBox.Show("Venta cancelada. El carrito se mantiene intacto.", "Venta Cancelada",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al procesar la venta: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private string GenerarReciboConPago(Venta venta, MetodoPagoDialog metodoPagoDialog)
        {
            var recibo = venta.GenerarRecibo();
            
            // Agregar información del pago
            recibo += "\n" + new string('=', 40) + "\n";
            recibo += "INFORMACIÓN DE PAGO\n";
            recibo += new string('=', 40) + "\n";
            recibo += $"Método de Pago: {metodoPagoDialog.MetodoPago}\n";
            
            if (metodoPagoDialog.MetodoPago == "Efectivo")
            {
                recibo += $"Cantidad Entregada: ${metodoPagoDialog.CantidadEntregada:N0}\n";
                if (metodoPagoDialog.Cambio > 0)
                {
                    recibo += $"Cambio: ${metodoPagoDialog.Cambio:N0}\n";
                }
                else
                {
                    recibo += "Cantidad Exacta\n";
                }
            }
            else if (metodoPagoDialog.MetodoPago == "ATH" || metodoPagoDialog.MetodoPago == "Tarjeta")
            {
                recibo += "Pago procesado electrónicamente\n";
                if (!string.IsNullOrEmpty(metodoPagoDialog.PIN))
                {
                    // Mostrar PIN enmascarado para seguridad
                    recibo += $"Autorización: ****{metodoPagoDialog.PIN.Substring(2)}\n";
                }
                recibo += "Transacción Aprobada ✓\n";
            }
            else
            {
                recibo += "Pago procesado electrónicamente\n";
            }
            
            recibo += new string('=', 40) + "\n";
            recibo += "¡GRACIAS POR SU COMPRA!\n";
            recibo += new string('=', 40);
            
            return recibo;
        }

        private void BtnAgregarProducto_Click(object sender, RoutedEventArgs e)
        {
            if (!ServicioAutenticacion.PuedeGestionarInventario()) return;

            var dialog = new ProductoDialog();
            if (dialog.ShowDialog() == true)
            {
                ServicioInventario.AgregarProducto(dialog.Producto);
                CargarCategorias();
                CargarProductos();
                ActualizarEstadisticas();
            }
        }

        private void BtnEditarProducto_Click(object sender, RoutedEventArgs e)
        {
            if (!ServicioAutenticacion.PuedeGestionarInventario()) return;

            var productoSeleccionado = GridInventario.SelectedItem as Producto;
            if (productoSeleccionado == null)
            {
                MessageBox.Show("Seleccione un producto para editar.", "Información",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var dialog = new ProductoDialog(productoSeleccionado);
            if (dialog.ShowDialog() == true)
            {
                ServicioInventario.ActualizarProducto(dialog.Producto);
                CargarCategorias();
                CargarProductos();
                ActualizarEstadisticas();
            }
        }

        private void BtnEliminarProducto_Click(object sender, RoutedEventArgs e)
        {
            if (!ServicioAutenticacion.PuedeGestionarInventario()) return;

            var productoSeleccionado = GridInventario.SelectedItem as Producto;
            if (productoSeleccionado == null)
            {
                MessageBox.Show("Seleccione un producto para eliminar.", "Información",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var resultado = MessageBox.Show($"¿Está seguro de que desea eliminar el producto '{productoSeleccionado.Nombre}'?",
                "Confirmar Eliminación", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                ServicioInventario.EliminarProducto(productoSeleccionado.Id);
                CargarCategorias();
                CargarProductos();
                ActualizarEstadisticas();
            }
        }

        private void BtnCrearUsuario_Click(object sender, RoutedEventArgs e)
        {
            if (!ServicioAutenticacion.PuedeGestionarUsuarios()) return;

            var dialog = new UsuarioDialog();
            if (dialog.ShowDialog() == true)
            {
                CargarUsuarios();
            }
        }

        private void BtnEditarUsuario_Click(object sender, RoutedEventArgs e)
        {
            if (!ServicioAutenticacion.PuedeGestionarUsuarios()) return;

            var usuarioSeleccionado = GridUsuarios.SelectedItem as Usuario;
            if (usuarioSeleccionado == null)
            {
                MessageBox.Show("Seleccione un usuario para editar.", "Información",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var dialog = new UsuarioDialog(usuarioSeleccionado);
            if (dialog.ShowDialog() == true)
            {
                CargarUsuarios();
            }
        }

        private void BtnEliminarUsuario_Click(object sender, RoutedEventArgs e)
        {
            if (!ServicioAutenticacion.PuedeGestionarUsuarios()) return;

            var usuarioSeleccionado = GridUsuarios.SelectedItem as Usuario;
            if (usuarioSeleccionado == null)
            {
                MessageBox.Show("Seleccione un usuario para eliminar.", "Información",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            // Verificar si es el usuario admin principal
            if (usuarioSeleccionado.NombreUsuario.ToLower() == "admin")
            {
                MessageBox.Show("No se puede eliminar el usuario administrador principal.", "Operación No Permitida",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Verificar si es el usuario actual
            if (ServicioAutenticacion.UsuarioActual != null && 
                ServicioAutenticacion.UsuarioActual.Id == usuarioSeleccionado.Id)
            {
                MessageBox.Show("No puede eliminar su propia cuenta mientras está logueado.", "Operación No Permitida",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var resultado = MessageBox.Show(
                $"¿Está seguro de que desea eliminar el usuario '{usuarioSeleccionado.NombreUsuario}'?\n\nEsta acción no se puede deshacer.",
                "Confirmar Eliminación", 
                MessageBoxButton.YesNo, 
                MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                bool eliminado = ServicioAutenticacion.EliminarUsuario(usuarioSeleccionado.Id);
                
                if (eliminado)
                {
                    MessageBox.Show("Usuario eliminado exitosamente.", "Éxito",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    CargarUsuarios();
                }
                else
                {
                    MessageBox.Show("Error al eliminar el usuario.", "Error",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void BtnVerRecibo_Click(object sender, RoutedEventArgs e)
        {
            var venta = ((FrameworkElement)sender).DataContext as Venta;
            if (venta != null)
            {
                MessageBox.Show(venta.GenerarRecibo(), $"Recibo #{venta.NumeroVenta:D6}",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void BtnDescargarPDF_Click(object sender, RoutedEventArgs e)
        {
            var venta = ((FrameworkElement)sender).DataContext as Venta;
            if (venta != null)
            {
                try
                {
                    var rutaPDF = ServicioVentas.GenerarReciboPDF(venta);
                    var resultado = MessageBox.Show($"PDF generado exitosamente.\n\n¿Desea abrir el archivo?\n\nRuta: {rutaPDF}",
                        "PDF Generado", MessageBoxButton.YesNo, MessageBoxImage.Information);

                    if (resultado == MessageBoxResult.Yes)
                    {
                        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(rutaPDF) { UseShellExecute = true });
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al generar PDF: {ex.Message}", "Error",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void BtnCerrarSesion_Click(object sender, RoutedEventArgs e)
        {
            var resultado = MessageBox.Show("¿Está seguro de que desea cerrar sesión?",
                "Cerrar Sesión", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                ServicioAutenticacion.CerrarSesion();
                var loginWindow = new LoginWindow();
                loginWindow.Show();
                this.Close();
            }
        }

        private void ItemsCarrito_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            ActualizarTotales();
        }

        private void MainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            timer?.Stop();
        }

        // Eventos para cajas de estadísticas clickeables
        private void Border_VentasHoy_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (!ServicioAutenticacion.PuedeVerEstadisticas()) return;
            
            var dialog = new DetallesEstadisticasDialog();
            dialog.MostrarVentasHoy();
            dialog.ShowDialog();
        }

        private void Border_CantidadVentas_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (!ServicioAutenticacion.PuedeVerEstadisticas()) return;
            
            var dialog = new DetallesEstadisticasDialog();
            dialog.MostrarCantidadVentas();
            dialog.ShowDialog();
        }

        private void Border_TotalProductos_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (!ServicioAutenticacion.PuedeVerEstadisticas()) return;
            
            var dialog = new DetallesEstadisticasDialog();
            dialog.MostrarTotalProductos();
            dialog.ShowDialog();
        }

        private void Border_StockCritico_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (!ServicioAutenticacion.PuedeVerEstadisticas()) return;
            
            var dialog = new DetallesEstadisticasDialog();
            dialog.MostrarStockCritico();
            dialog.ShowDialog();
        }

        private void Border_ProductoTop_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (!ServicioAutenticacion.PuedeVerEstadisticas()) return;
            
            var dialog = new DetallesEstadisticasDialog();
            dialog.MostrarProductoMasVendido();
            dialog.ShowDialog();
        }

        private void Border_PromedioVenta_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (!ServicioAutenticacion.PuedeVerEstadisticas()) return;
            
            var dialog = new DetallesEstadisticasDialog();
            dialog.MostrarPromedioVenta();
            dialog.ShowDialog();
        }
    }
}