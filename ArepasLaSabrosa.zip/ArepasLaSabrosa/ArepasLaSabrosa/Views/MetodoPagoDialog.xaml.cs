using System;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace ArepasLaSabrosa.Views
{
    public partial class MetodoPagoDialog : Window
    {
        public string MetodoPago { get; private set; } = string.Empty;
        public decimal CantidadEntregada { get; private set; }
        public decimal Cambio { get; private set; }
        public string PIN { get; private set; } = string.Empty;
        private decimal _totalPagar;

        public MetodoPagoDialog(decimal totalPagar)
        {
            InitializeComponent();
            _totalPagar = totalPagar;
            LblTotalPagar.Text = $"${totalPagar:N0}";
            CmbMetodoPago.SelectedIndex = 0; // Efectivo por defecto
        }

        private void CmbMetodoPago_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbMetodoPago.SelectedItem is ComboBoxItem item)
            {
                MetodoPago = item.Tag.ToString() ?? "";
                
                bool esEfectivo = MetodoPago == "Efectivo";
                bool requierePIN = MetodoPago == "ATH" || MetodoPago == "Tarjeta";
                
                PanelEfectivo.Visibility = esEfectivo ? Visibility.Visible : Visibility.Collapsed;
                PanelPIN.Visibility = requierePIN ? Visibility.Visible : Visibility.Collapsed;
                PanelCambio.Visibility = Visibility.Collapsed;
                
                if (esEfectivo)
                {
                    TxtCantidadEntregada.Focus();
                    BtnConfirmar.IsEnabled = false;
                }
                else if (requierePIN)
                {
                    TxtPIN.Focus();
                    TxtPIN.Clear();
                    LblPINStatus.Visibility = Visibility.Collapsed;
                    BtnConfirmar.IsEnabled = false;
                    CantidadEntregada = _totalPagar;
                    Cambio = 0;
                }
                else
                {
                    BtnConfirmar.IsEnabled = true;
                    CantidadEntregada = _totalPagar;
                    Cambio = 0;
                }
            }
        }

        private void TxtCantidadEntregada_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (decimal.TryParse(TxtCantidadEntregada.Text, out decimal cantidad))
            {
                CantidadEntregada = cantidad;
                Cambio = cantidad - _totalPagar;
                
                LblCambio.Text = $"${Cambio:N0}";
                
                if (Cambio >= 0)
                {
                    PanelCambio.Visibility = Visibility.Visible;
                    BtnConfirmar.IsEnabled = true;
                    
                    // Cambiar color según si hay cambio o es exacto
                    if (Cambio == 0)
                    {
                        LblCambio.Text = "Cantidad Exacta";
                        PanelCambio.Background = new System.Windows.Media.SolidColorBrush(
                            System.Windows.Media.Color.FromRgb(212, 237, 218)); // Verde claro
                    }
                    else
                    {
                        LblCambio.Text = $"${Cambio:N0}";
                        PanelCambio.Background = new System.Windows.Media.SolidColorBrush(
                            System.Windows.Media.Color.FromRgb(255, 243, 205)); // Amarillo claro
                    }
                }
                else
                {
                    PanelCambio.Visibility = Visibility.Collapsed;
                    BtnConfirmar.IsEnabled = false;
                }
            }
            else
            {
                PanelCambio.Visibility = Visibility.Collapsed;
                BtnConfirmar.IsEnabled = false;
                CantidadEntregada = 0;
                Cambio = 0;
            }
        }

        private void TxtCantidadEntregada_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Solo permitir números y punto decimal
            Regex regex = new Regex(@"^[0-9.]+$");
            e.Handled = !regex.IsMatch(e.Text);
        }

        private void TxtPIN_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Solo permitir números
            Regex regex = new Regex(@"^[0-9]+$");
            e.Handled = !regex.IsMatch(e.Text);
        }

        private void TxtPIN_PasswordChanged(object sender, RoutedEventArgs e)
        {
            var pin = TxtPIN.Password;
            
            if (pin.Length == 4)
            {
                PIN = pin;
                LblPINStatus.Text = "✓ PIN válido";
                LblPINStatus.Foreground = new System.Windows.Media.SolidColorBrush(
                    System.Windows.Media.Color.FromRgb(40, 167, 69)); // Verde
                LblPINStatus.Visibility = Visibility.Visible;
                BtnConfirmar.IsEnabled = true;
            }
            else if (pin.Length > 0)
            {
                PIN = "";
                LblPINStatus.Text = $"PIN debe tener 4 dígitos ({pin.Length}/4)";
                LblPINStatus.Foreground = new System.Windows.Media.SolidColorBrush(
                    System.Windows.Media.Color.FromRgb(220, 53, 69)); // Rojo
                LblPINStatus.Visibility = Visibility.Visible;
                BtnConfirmar.IsEnabled = false;
            }
            else
            {
                PIN = "";
                LblPINStatus.Visibility = Visibility.Collapsed;
                BtnConfirmar.IsEnabled = false;
            }
        }

        private void BtnConfirmar_Click(object sender, RoutedEventArgs e)
        {
            if (MetodoPago == "Efectivo" && CantidadEntregada < _totalPagar)
            {
                MessageBox.Show("La cantidad entregada no puede ser menor al total a pagar.",
                    "Cantidad Insuficiente", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if ((MetodoPago == "ATH" || MetodoPago == "Tarjeta") && PIN.Length != 4)
            {
                MessageBox.Show("Debe ingresar un PIN de 4 dígitos para procesar el pago.",
                    "PIN Requerido", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtPIN.Focus();
                return;
            }

            DialogResult = true;
            Close();
        }

        private void BtnCancelar_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}