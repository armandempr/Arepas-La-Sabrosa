using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using ArepasLaSabrosa.Services;

namespace ArepasLaSabrosa.Views
{
    public partial class DetallesEstadisticasDialog : Window
    {
        public DetallesEstadisticasDialog()
        {
            InitializeComponent();
        }

        public void MostrarVentasHoy()
        {
            LblTitulo.Text = "💰 VENTAS DE HOY - DETALLE";
            
            var ventasHoy = ServicioVentas.HistorialVentas
                .Where(v => v.Fecha.Date == DateTime.Today)
                .OrderByDescending(v => v.Fecha)
                .ToList();

            if (!ventasHoy.Any())
            {
                AgregarTexto("No hay ventas registradas para el día de hoy.", Colors.Gray);
                return;
            }

            AgregarTexto($"Total de ventas hoy: {ventasHoy.Count}", Colors.Black);
            AgregarTexto($"Monto total: ${ventasHoy.Sum(v => v.Total):N0}", Colors.Green);
            AgregarSeparador();

            foreach (var venta in ventasHoy)
            {
                AgregarVenta(venta);
            }
        }

        public void MostrarCantidadVentas()
        {
            LblTitulo.Text = "🛒 CANTIDAD DE VENTAS - DETALLE";
            
            var ventasPorDia = ServicioVentas.HistorialVentas
                .GroupBy(v => v.Fecha.Date)
                .OrderByDescending(g => g.Key)
                .Take(10)
                .ToList();

            if (!ventasPorDia.Any())
            {
                AgregarTexto("No hay ventas registradas.", Colors.Gray);
                return;
            }

            AgregarTexto("Ventas por día (últimos 10 días):", Colors.Black);
            AgregarSeparador();

            foreach (var grupo in ventasPorDia)
            {
                var fecha = grupo.Key.ToString("dd/MM/yyyy");
                var cantidad = grupo.Count();
                var total = grupo.Sum(v => v.Total);
                
                AgregarTexto($"📅 {fecha}: {cantidad} ventas - ${total:N0}", Colors.DarkBlue);
            }
        }

        public void MostrarTotalProductos()
        {
            LblTitulo.Text = "📦 PRODUCTOS EN INVENTARIO - DETALLE";
            
            var productos = ServicioInventario.Productos.OrderBy(p => p.Categoria).ThenBy(p => p.Nombre).ToList();
            
            if (!productos.Any())
            {
                AgregarTexto("No hay productos en el inventario.", Colors.Gray);
                return;
            }

            var categorias = productos.GroupBy(p => p.Categoria).ToList();
            AgregarTexto($"Total de productos: {productos.Count}", Colors.Black);
            AgregarTexto($"Categorías: {categorias.Count()}", Colors.Black);
            AgregarSeparador();

            foreach (var categoria in categorias)
            {
                AgregarTexto($"📂 {categoria.Key} ({categoria.Count()} productos):", Colors.DarkMagenta);
                
                foreach (var producto in categoria)
                {
                    var stockColor = producto.Stock <= 5 ? Colors.Red : Colors.Green;
                    AgregarTexto($"  • {producto.Nombre} - Stock: {producto.Stock} - ${producto.Precio:N0}", stockColor);
                }
                AgregarSeparador();
            }
        }

        public void MostrarStockCritico()
        {
            LblTitulo.Text = "⚠️ STOCK CRÍTICO - DETALLE";
            
            var productosCriticos = ServicioInventario.Productos
                .Where(p => p.Stock <= 5)
                .OrderBy(p => p.Stock)
                .ToList();

            if (!productosCriticos.Any())
            {
                AgregarTexto("¡Excelente! No hay productos con stock crítico.", Colors.Green);
                return;
            }

            AgregarTexto($"Productos con stock crítico (≤5): {productosCriticos.Count}", Colors.Red);
            AgregarSeparador();

            foreach (var producto in productosCriticos)
            {
                var color = producto.Stock == 0 ? Colors.Red : Colors.Orange;
                var estado = producto.Stock == 0 ? "SIN STOCK" : "STOCK BAJO";
                
                AgregarTexto($"⚠️ {producto.Nombre}", color);
                AgregarTexto($"   Stock: {producto.Stock} - {estado}", color);
                AgregarTexto($"   Categoría: {producto.Categoria}", Colors.Gray);
                AgregarTexto($"   Precio: ${producto.Precio:N0}", Colors.Gray);
                AgregarSeparador();
            }
        }

        public void MostrarProductoMasVendido()
        {
            LblTitulo.Text = "🏆 PRODUCTO MÁS VENDIDO - DETALLE";
            
            var productosVendidos = ServicioVentas.ObtenerProductosMasVendidos(10);
            
            if (!productosVendidos.Any())
            {
                AgregarTexto("No hay datos de productos vendidos.", Colors.Gray);
                return;
            }

            AgregarTexto("Top 10 productos más vendidos:", Colors.Black);
            AgregarSeparador();

            for (int i = 0; i < productosVendidos.Count; i++)
            {
                var item = productosVendidos[i];
                var emoji = i == 0 ? "🥇" : i == 1 ? "🥈" : i == 2 ? "🥉" : $"{i + 1}.";
                var color = i == 0 ? Colors.Gold : i == 1 ? Colors.Silver : i == 2 ? Colors.Orange : Colors.Black;
                
                AgregarTexto($"{emoji} {item.Producto} - {item.CantidadVendida} vendidos", color);
            }
        }

        public void MostrarPromedioVenta()
        {
            LblTitulo.Text = "📊 PROMEDIO DE VENTA - DETALLE";
            
            var ventas = ServicioVentas.HistorialVentas;
            
            if (!ventas.Any())
            {
                AgregarTexto("No hay ventas registradas para calcular promedios.", Colors.Gray);
                return;
            }

            var promedio = ventas.Average(v => v.Total);
            var ventaMayor = ventas.Max(v => v.Total);
            var ventaMenor = ventas.Min(v => v.Total);
            var totalVentas = ventas.Sum(v => v.Total);

            AgregarTexto($"📊 Estadísticas de Ventas:", Colors.Black);
            AgregarSeparador();
            AgregarTexto($"Promedio por venta: ${promedio:N0}", Colors.Blue);
            AgregarTexto($"Venta más alta: ${ventaMayor:N0}", Colors.Green);
            AgregarTexto($"Venta más baja: ${ventaMenor:N0}", Colors.Orange);
            AgregarTexto($"Total vendido: ${totalVentas:N0}", Colors.Purple);
            AgregarTexto($"Número de ventas: {ventas.Count}", Colors.Gray);

            // Análisis por rangos
            AgregarSeparador();
            AgregarTexto("Distribución de ventas por rangos:", Colors.Black);
            
            var rangos = new[] 
            { 
                (min: 0m, max: 10000m, nombre: "Hasta $10,000"),
                (min: 10001m, max: 25000m, nombre: "$10,001 - $25,000"),
                (min: 25001m, max: 50000m, nombre: "$25,001 - $50,000"),
                (min: 50001m, max: decimal.MaxValue, nombre: "Más de $50,000")
            };

            foreach (var rango in rangos)
            {
                var cantidad = ventas.Count(v => v.Total >= rango.min && v.Total <= rango.max);
                if (cantidad > 0)
                {
                    AgregarTexto($"  {rango.nombre}: {cantidad} ventas", Colors.DarkBlue);
                }
            }
        }

        private void AgregarTexto(string texto, Color color)
        {
            var textBlock = new TextBlock
            {
                Text = texto,
                Foreground = new SolidColorBrush(color),
                FontSize = 12,
                Margin = new Thickness(0, 2, 0, 2),
                TextWrapping = TextWrapping.Wrap
            };
            PanelContenido.Children.Add(textBlock);
        }

        private void AgregarSeparador()
        {
            var separator = new Border
            {
                Height = 1,
                Background = new SolidColorBrush(Colors.LightGray),
                Margin = new Thickness(0, 8, 0, 8)
            };
            PanelContenido.Children.Add(separator);
        }

        private void AgregarVenta(ArepasLaSabrosa.Models.Venta venta)
        {
            var stackPanel = new StackPanel
            {
                Margin = new Thickness(0, 5, 0, 10),
                Background = new SolidColorBrush(Colors.WhiteSmoke)
            };

            // Encabezado de la venta
            var header = new TextBlock
            {
                Text = $"🧾 Venta #{venta.NumeroVenta:D6} - {venta.Fecha:HH:mm:ss} - ${venta.Total:N0}",
                FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush(Colors.DarkBlue),
                Margin = new Thickness(5)
            };
            stackPanel.Children.Add(header);

            // Items de la venta
            foreach (var item in venta.Items)
            {
                var itemText = new TextBlock
                {
                    Text = $"  • {item.Producto.Nombre} x{item.Cantidad} = ${item.Total:N0}",
                    Margin = new Thickness(10, 2, 5, 2),
                    Foreground = new SolidColorBrush(Colors.Black)
                };
                stackPanel.Children.Add(itemText);
            }

            PanelContenido.Children.Add(stackPanel);
        }

        private void BtnCerrar_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}