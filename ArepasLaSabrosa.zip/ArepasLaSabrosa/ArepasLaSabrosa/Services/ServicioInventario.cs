using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using ArepasLaSabrosa.Models;

namespace ArepasLaSabrosa.Services
{
    public static class ServicioInventario
    {
        private static readonly ObservableCollection<Producto> _productos = new();
        private static int _siguienteId = 1;

        public static ObservableCollection<Producto> Productos => _productos;

        static ServicioInventario()
        {
            InicializarProductosPorDefecto();
        }

        private static void InicializarProductosPorDefecto()
        {
            var productosIniciales = new[]
            {
                // Arepas
                new Producto(GetNextId(), "Arepa de Queso", 8000, 25, "Arepas", "Arepa tradicional con queso costeño"),
                new Producto(GetNextId(), "Arepa de Pollo", 10000, 20, "Arepas", "Arepa rellena con pollo desmechado"),
                new Producto(GetNextId(), "Arepa de Carne", 12000, 15, "Arepas", "Arepa con carne de res desmechada"),
                new Producto(GetNextId(), "Arepa de Chorizo", 9000, 18, "Arepas", "Arepa con chorizo santandereano"),
                new Producto(GetNextId(), "Arepa de Huevo", 7500, 22, "Arepas", "Arepa con huevos pericos"),
                new Producto(GetNextId(), "Arepa Reina Pepiada", 11000, 16, "Arepas", "Arepa con pollo y aguacate"),
                new Producto(GetNextId(), "Arepa de Chicharrón", 9500, 14, "Arepas", "Arepa con chicharrón prensado"),
                new Producto(GetNextId(), "Arepa Mixta", 13000, 12, "Arepas", "Arepa con pollo, carne y queso"),

                // Bebidas
                new Producto(GetNextId(), "Jugo de Maracuyá", 4000, 30, "Bebidas", "Jugo natural de maracuyá"),
                new Producto(GetNextId(), "Jugo de Mango", 4000, 28, "Bebidas", "Jugo natural de mango"),
                new Producto(GetNextId(), "Limonada Natural", 3500, 35, "Bebidas", "Limonada natural refrescante"),
                new Producto(GetNextId(), "Agua Panela", 2500, 40, "Bebidas", "Agua de panela tradicional"),
                new Producto(GetNextId(), "Café Colombiano", 2000, 50, "Bebidas", "Café tinto colombiano"),
                new Producto(GetNextId(), "Chocolate Caliente", 3000, 25, "Bebidas", "Chocolate santafereño"),
                new Producto(GetNextId(), "Cocacola", 2800, 60, "Bebidas", "Gaseosa Coca-Cola"),
                new Producto(GetNextId(), "Agua Mineral", 2000, 45, "Bebidas", "Agua mineral natural"),

                // Acompañamientos
                new Producto(GetNextId(), "Yuca Frita", 5000, 20, "Acompañamientos", "Yuca frita crispy"),
                new Producto(GetNextId(), "Patacones", 4500, 25, "Acompañamientos", "Plátano verde frito"),
                new Producto(GetNextId(), "Ensalada", 3000, 15, "Acompañamientos", "Ensalada fresca mixta"),
                new Producto(GetNextId(), "Queso Costeño", 2000, 30, "Acompañamientos", "Porción de queso costeño"),

                // Otros
                new Producto(GetNextId(), "Postre del Día", 4000, 10, "Otros", "Postre especial del día"),
                new Producto(GetNextId(), "Salsa Ají", 1000, 50, "Otros", "Salsa ají picante casera")
            };

            foreach (var producto in productosIniciales)
            {
                _productos.Add(producto);
            }
        }

        private static int GetNextId() => _siguienteId++;

        public static bool AgregarProducto(Producto producto)
        {
            if (ServicioAutenticacion.PuedeGestionarInventario())
            {
                producto.Id = GetNextId();
                _productos.Add(producto);
                return true;
            }
            return false;
        }

        public static bool ActualizarProducto(Producto producto)
        {
            if (!ServicioAutenticacion.PuedeGestionarInventario()) return false;

            var productoExistente = _productos.FirstOrDefault(p => p.Id == producto.Id);
            if (productoExistente != null)
            {
                productoExistente.Nombre = producto.Nombre;
                productoExistente.Precio = producto.Precio;
                productoExistente.Stock = producto.Stock;
                productoExistente.Categoria = producto.Categoria;
                productoExistente.Descripcion = producto.Descripcion;
                return true;
            }
            return false;
        }

        public static bool EliminarProducto(int id)
        {
            if (!ServicioAutenticacion.PuedeGestionarInventario()) return false;

            var producto = _productos.FirstOrDefault(p => p.Id == id);
            if (producto != null)
            {
                _productos.Remove(producto);
                return true;
            }
            return false;
        }

        public static Producto? ObtenerProducto(int id)
        {
            return _productos.FirstOrDefault(p => p.Id == id);
        }

        public static List<string> ObtenerCategorias()
        {
            return _productos.Select(p => p.Categoria).Distinct().OrderBy(c => c).ToList();
        }

        public static ObservableCollection<Producto> FiltrarPorCategoria(string? categoria)
        {
            if (string.IsNullOrEmpty(categoria) || categoria == "Todas")
            {
                return _productos;
            }

            var productosFiltrados = new ObservableCollection<Producto>(
                _productos.Where(p => p.Categoria.Equals(categoria, StringComparison.OrdinalIgnoreCase))
            );
            return productosFiltrados;
        }

        public static void ActualizarStock(int productoId, int cantidadVendida)
        {
            var producto = _productos.FirstOrDefault(p => p.Id == productoId);
            if (producto != null && producto.Stock >= cantidadVendida)
            {
                producto.Stock -= cantidadVendida;
            }
        }

        public static void RestaurarStock(int productoId, int cantidad)
        {
            var producto = _productos.FirstOrDefault(p => p.Id == productoId);
            if (producto != null)
            {
                producto.Stock += cantidad;
            }
        }
    }
}