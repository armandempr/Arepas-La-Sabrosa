using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ArepasLaSabrosa.Models;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;
using iText.Kernel.Colors;
using iText.IO.Font.Constants;
using iText.Kernel.Font;

namespace ArepasLaSabrosa.Services
{
    // Servicio que maneja las ventas y generación de reportes
    public static class ServicioVentas
    {
        // Lista que guarda el historial de todas las ventas
        private static readonly List<Venta> _historialVentas = new();
        // Contador para generar números de venta consecutivos
        private static int _siguienteNumero = 1;

        // Propiedad pública para acceder al historial de ventas (solo lectura)
        public static IReadOnlyList<Venta> HistorialVentas => _historialVentas.AsReadOnly();

        // Crea una nueva venta vacía
        public static Venta CrearNuevaVenta()
        {
            return new Venta(_siguienteNumero);
        }

        // Procesa y guarda una venta completada
        public static bool ProcesarVenta(Venta venta)
        {
            if (venta.Items.Count == 0) return false; // No procesa ventas vacías

            // El stock ya fue verificado y reducido cuando se agregaron los productos al carrito
            // No necesitamos verificar ni actualizar stock nuevamente aquí

            // Asigna información del usuario actual
            venta.NombreCajero = ServicioAutenticacion.UsuarioActual?.NombreUsuario ?? "Sistema";
            venta.NumeroVenta = _siguienteNumero++; // Asigna número y aumenta contador

            // Guarda en el historial de ventas
            _historialVentas.Add(venta);

            return true;
        }

        public static string GenerarReciboPDF(Venta venta)
        {
            try
            {
                string rutaArchivo = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
                    $"Recibo_Arepa_{venta.NumeroVenta:D6}_{DateTime.Now:yyyyMMdd_HHmmss}.pdf"
                );

                using (var writer = new PdfWriter(rutaArchivo))
                using (var pdf = new PdfDocument(writer))
                using (var document = new Document(pdf))
                {
                    // Configurar fuente
                    var fuente = PdfFontFactory.CreateFont(StandardFonts.HELVETICA);
                    var fuenteBold = PdfFontFactory.CreateFont(StandardFonts.HELVETICA_BOLD);

                    // Encabezado
                    var titulo = new Paragraph("🫓 AREPAS LA SABROSA 🫓")
                        .SetFont(fuenteBold)
                        .SetFontSize(20)
                        .SetTextAlignment(TextAlignment.CENTER)
                        .SetFontColor(ColorConstants.DARK_GRAY);
                    document.Add(titulo);

                    var subtitulo = new Paragraph("Recibo de Venta")
                        .SetFont(fuente)
                        .SetFontSize(14)
                        .SetTextAlignment(TextAlignment.CENTER)
                        .SetMarginBottom(20);
                    document.Add(subtitulo);

                    // Información de la venta
                    var info = new Paragraph()
                        .SetFont(fuente)
                        .SetFontSize(10);
                    
                    info.Add(new Text($"Factura #: {venta.NumeroVenta:D6}\n").SetFont(fuenteBold));
                    info.Add($"Fecha: {venta.Fecha:dd/MM/yyyy HH:mm:ss}\n");
                    info.Add($"Cajero: {venta.NombreCajero}\n\n");
                    document.Add(info);

                    // Tabla de productos
                    var tabla = new Table(UnitValue.CreatePercentArray(new float[] { 3, 1, 2, 2 }))
                        .SetWidth(UnitValue.CreatePercentValue(100));

                    // Encabezados de tabla
                    tabla.AddHeaderCell(new Cell().Add(new Paragraph("Producto").SetFont(fuenteBold)));
                    tabla.AddHeaderCell(new Cell().Add(new Paragraph("Cant.").SetFont(fuenteBold)));
                    tabla.AddHeaderCell(new Cell().Add(new Paragraph("Precio Unit.").SetFont(fuenteBold)));
                    tabla.AddHeaderCell(new Cell().Add(new Paragraph("Total").SetFont(fuenteBold)));

                    // Productos
                    foreach (var item in venta.Items)
                    {
                        tabla.AddCell(new Cell().Add(new Paragraph(item.Producto.Nombre).SetFont(fuente)));
                        tabla.AddCell(new Cell().Add(new Paragraph(item.Cantidad.ToString()).SetFont(fuente).SetTextAlignment(TextAlignment.CENTER)));
                        tabla.AddCell(new Cell().Add(new Paragraph($"${item.PrecioUnitario:N0}").SetFont(fuente).SetTextAlignment(TextAlignment.RIGHT)));
                        tabla.AddCell(new Cell().Add(new Paragraph($"${item.Total:N0}").SetFont(fuente).SetTextAlignment(TextAlignment.RIGHT)));
                    }

                    document.Add(tabla);

                    // Totales
                    var totales = new Paragraph()
                        .SetFont(fuente)
                        .SetFontSize(12)
                        .SetTextAlignment(TextAlignment.RIGHT)
                        .SetMarginTop(20);

                    totales.Add($"Subtotal: ${venta.Subtotal:N0}\n");
                    totales.Add($"IVA (19%): ${venta.IVA:N0}\n");
                    totales.Add(new Text($"TOTAL: ${venta.Total:N0}").SetFont(fuenteBold).SetFontSize(14));
                    
                    document.Add(totales);

                    // Pie de página
                    var pie = new Paragraph("\n¡Gracias por su compra!\nVuelva pronto 🫓")
                        .SetFont(fuente)
                        .SetFontSize(10)
                        .SetTextAlignment(TextAlignment.CENTER)
                        .SetMarginTop(30);
                    document.Add(pie);
                }

                return rutaArchivo;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error al generar PDF: {ex.Message}", ex);
            }
        }

        public static List<Venta> ObtenerVentasPorFecha(DateTime fecha)
        {
            return _historialVentas.Where(v => v.Fecha.Date == fecha.Date).ToList();
        }

        public static List<Venta> ObtenerVentasPorPeriodo(DateTime fechaInicio, DateTime fechaFin)
        {
            return _historialVentas.Where(v => v.Fecha.Date >= fechaInicio.Date && v.Fecha.Date <= fechaFin.Date).ToList();
        }

        public static decimal ObtenerTotalVentasDia(DateTime fecha)
        {
            return ObtenerVentasPorFecha(fecha).Sum(v => v.Total);
        }

        public static int ObtenerCantidadVentasDia(DateTime fecha)
        {
            return ObtenerVentasPorFecha(fecha).Count;
        }

        public static List<(string Producto, int CantidadVendida, decimal TotalVentas)> ObtenerProductosMasVendidos(int top = 10)
        {
            return _historialVentas
                .SelectMany(v => v.Items)
                .GroupBy(i => i.Producto.Nombre)
                .Select(g => (
                    Producto: g.Key,
                    CantidadVendida: g.Sum(i => i.Cantidad),
                    TotalVentas: g.Sum(i => i.Total)
                ))
                .OrderByDescending(x => x.CantidadVendida)
                .Take(top)
                .ToList();
        }

        public static List<(string Cajero, int NumeroVentas, decimal TotalVentas)> ObtenerEstadisticasCajeros()
        {
            return _historialVentas
                .GroupBy(v => v.NombreCajero)
                .Select(g => (
                    Cajero: g.Key,
                    NumeroVentas: g.Count(),
                    TotalVentas: g.Sum(v => v.Total)
                ))
                .OrderByDescending(x => x.TotalVentas)
                .ToList();
        }
    }
}