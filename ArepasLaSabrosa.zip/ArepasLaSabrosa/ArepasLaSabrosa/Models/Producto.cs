using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace ArepasLaSabrosa.Models
{
    // Clase que representa un producto en el inventario
    // Implementa INotifyPropertyChanged para actualizar la UI automáticamente
    public class Producto : INotifyPropertyChanged
    {
        // Campos privados para las propiedades
        private int _id;
        private string _nombre = string.Empty;
        private decimal _precio;
        private int _stock;
        private string _categoria = string.Empty;
        private string _descripcion = string.Empty;

        // Propiedades del producto con notificación de cambios
        public int Id
        {
            get => _id;
            set => SetProperty(ref _id, value);
        }

        public string Nombre
        {
            get => _nombre;
            set => SetProperty(ref _nombre, value);
        }

        public decimal Precio
        {
            get => _precio;
            set => SetProperty(ref _precio, value);
        }

        public int Stock
        {
            get => _stock;
            set => SetProperty(ref _stock, value);
        }

        public string Categoria
        {
            get => _categoria;
            set => SetProperty(ref _categoria, value);
        }

        public string Descripcion
        {
            get => _descripcion;
            set => SetProperty(ref _descripcion, value);
        }

        public DateTime FechaCreacion { get; set; } = DateTime.Now;

        // Constructor vacío
        public Producto() { }

        // Constructor que crea un producto con todos los datos
        public Producto(int id, string nombre, decimal precio, int stock, string categoria, string descripcion = "")
        {
            Id = id;
            Nombre = nombre;
            Precio = precio;
            Stock = stock;
            Categoria = categoria;
            Descripcion = descripcion;
        }

        // Verifica si hay suficiente stock disponible
        public bool TieneStock(int cantidad = 1)
        {
            return Stock >= cantidad;
        }

        // Reduce el stock cuando se vende un producto
        public void ReducirStock(int cantidad)
        {
            if (cantidad <= 0) throw new ArgumentException("La cantidad debe ser positiva");
            if (!TieneStock(cantidad)) throw new InvalidOperationException("Stock insuficiente");
            Stock -= cantidad;
        }

        // Aumenta el stock cuando llega mercancía
        public void AumentarStock(int cantidad)
        {
            if (cantidad <= 0) throw new ArgumentException("La cantidad debe ser positiva");
            Stock += cantidad;
        }

        // Evento que se dispara cuando una propiedad cambia
        public event PropertyChangedEventHandler? PropertyChanged;

        // Método que notifica cambios en las propiedades
        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        // Método helper para cambiar propiedades y notificar cambios
        protected bool SetProperty<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
        {
            if (Equals(field, value)) return false;
            field = value;
            OnPropertyChanged(propertyName);
            return true;
        }
    }
}