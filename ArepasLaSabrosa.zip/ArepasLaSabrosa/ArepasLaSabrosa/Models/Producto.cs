using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace ArepasLaSabrosa.Models
{
    public class Producto : INotifyPropertyChanged
    {
        private int _id;
        private string _nombre = string.Empty;
        private decimal _precio;
        private int _stock;
        private string _categoria = string.Empty;
        private string _descripcion = string.Empty;

        public int Id
        {
            get => _id;
            set => SetProperty(ref _id, value);
        }

        public string Nombre
        {
            get => _nombre;
            set => SetProperty(ref _nombre, value);
        }

        public decimal Precio
        {
            get => _precio;
            set => SetProperty(ref _precio, value);
        }

        public int Stock
        {
            get => _stock;
            set => SetProperty(ref _stock, value);
        }

        public string Categoria
        {
            get => _categoria;
            set => SetProperty(ref _categoria, value);
        }

        public string Descripcion
        {
            get => _descripcion;
            set => SetProperty(ref _descripcion, value);
        }

        public DateTime FechaCreacion { get; set; } = DateTime.Now;

        public Producto() { }

        public Producto(int id, string nombre, decimal precio, int stock, string categoria, string descripcion = "")
        {
            Id = id;
            Nombre = nombre;
            Precio = precio;
            Stock = stock;
            Categoria = categoria;
            Descripcion = descripcion;
        }

        public bool TieneStock(int cantidad = 1)
        {
            return Stock >= cantidad;
        }

        public void ReducirStock(int cantidad)
        {
            if (cantidad <= 0) throw new ArgumentException("La cantidad debe ser positiva");
            if (!TieneStock(cantidad)) throw new InvalidOperationException("Stock insuficiente");
            Stock -= cantidad;
        }

        public void AumentarStock(int cantidad)
        {
            if (cantidad <= 0) throw new ArgumentException("La cantidad debe ser positiva");
            Stock += cantidad;
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        protected bool SetProperty<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
        {
            if (Equals(field, value)) return false;
            field = value;
            OnPropertyChanged(propertyName);
            return true;
        }
    }
}