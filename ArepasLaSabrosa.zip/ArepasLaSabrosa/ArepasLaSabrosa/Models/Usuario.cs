using System;
using System.Security.Cryptography;
using System.Text;

namespace ArepasLaSabrosa.Models
{
    public enum RolUsuario
    {
        Admin = 1,
        Cajero = 2,
        UsuarioInventario = 3,
        SelfCheckout = 4
    }

    public class Usuario
    {
        public int Id { get; set; }
        public string NombreUsuario { get; set; } = "";
        public string PasswordHash { get; set; } = "";
        public RolUsuario Rol { get; set; }
        public bool EstaActivo { get; set; } = true;
        public DateTime FechaCreacion { get; set; } = DateTime.Now;

        public Usuario()
        {
            NombreUsuario = "";
            PasswordHash = "";
        }

        public Usuario(string nombreUsuario, string password, RolUsuario rol)
        {
            NombreUsuario = nombreUsuario;
            PasswordHash = HashPassword(password);
            Rol = rol;
        }

        public static string HashPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(bytes);
            }
        }

        public bool VerificarPassword(string password)
        {
            return PasswordHash == HashPassword(password);
        }

        public void CambiarPassword(string nuevaPassword)
        {
            PasswordHash = HashPassword(nuevaPassword);
        }

        public static string ObtenerDescripcionRol(RolUsuario rol)
        {
            return rol switch
            {
                RolUsuario.Admin => "Administrador/Gerente",
                RolUsuario.Cajero => "Cajero",
                RolUsuario.UsuarioInventario => "Usuario de Inventario",
                RolUsuario.SelfCheckout => "Self-Checkout",
                _ => "Desconocido"
            };
        }
    }
}