using System;
using System.Security.Cryptography;
using System.Text;

namespace ArepasLaSabrosa.Models
{
    // Enum que define los diferentes roles de usuario en el sistema
    public enum RolUsuario
    {
        Admin = 1,              // Administrador con todos los permisos
        Cajero = 2,             // Cajero que puede hacer ventas
        UsuarioInventario = 3,  // Usuario que maneja inventario
        SelfCheckout = 4        // Usuario para auto-servicio
    }

    // Clase que representa un usuario del sistema
    public class Usuario
    {
        // Propiedades básicas del usuario
        public int Id { get; set; }                    // ID único del usuario
        public string NombreUsuario { get; set; } = ""; // Nombre de usuario para login
        public string PasswordHash { get; set; } = ""; // Contraseña encriptada
        public RolUsuario Rol { get; set; }            // Rol del usuario
        public bool EstaActivo { get; set; } = true;   // Si el usuario está activo
        public DateTime FechaCreacion { get; set; } = DateTime.Now; // Fecha de creación

        // Constructor vacío
        public Usuario()
        {
            NombreUsuario = "";
            PasswordHash = "";
        }

        // Constructor que crea un usuario con datos iniciales
        public Usuario(string nombreUsuario, string password, RolUsuario rol)
        {
            NombreUsuario = nombreUsuario;
            PasswordHash = HashPassword(password); // Encripta la contraseña
            Rol = rol;
        }

        // Método que encripta una contraseña usando SHA256
        public static string HashPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                // Convierte la contraseña a bytes y la encripta
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(bytes);
            }
        }

        // Verifica si una contraseña coincide con la guardada
        public bool VerificarPassword(string password)
        {
            return PasswordHash == HashPassword(password);
        }

        // Cambia la contraseña del usuario
        public void CambiarPassword(string nuevaPassword)
        {
            PasswordHash = HashPassword(nuevaPassword);
        }

        public static string ObtenerDescripcionRol(RolUsuario rol)
        {
            return rol switch
            {
                RolUsuario.Admin => "Administrador/Gerente",
                RolUsuario.Cajero => "Cajero",
                RolUsuario.UsuarioInventario => "Usuario de Inventario",
                RolUsuario.SelfCheckout => "Self-Checkout",
                _ => "Desconocido"
            };
        }
    }
}