using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace ArepasLaSabrosa.Models
{
    // Clase que representa un item individual en una venta
    public class ItemVenta : INotifyPropertyChanged
    {
        private int _cantidad;

        public Producto Producto { get; set; } = null!;  // El producto que se está vendiendo
        
        // Cantidad de productos (con notificación de cambios para la UI)
        public int Cantidad 
        { 
            get => _cantidad;
            set 
            {
                if (_cantidad != value)
                {
                    _cantidad = value;
                    OnPropertyChanged();                    // Notifica que la cantidad cambió
                    OnPropertyChanged(nameof(Total));       // Notifica que el total cambió
                }
            }
        }
        
        public decimal PrecioUnitario { get; set; }         // Precio al momento de la venta
        public decimal Total => Cantidad * PrecioUnitario;  // Calcula el total del item

        // Evento para notificar cambios en las propiedades
        public event PropertyChangedEventHandler? PropertyChanged;

        // Método que notifica cambios (usado por WPF para actualizar la UI)
        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        // Método público para notificar cambios externamente
        public void NotifyPropertyChanged(string propertyName)
        {
            OnPropertyChanged(propertyName);
        }

        // Constructor vacío
        public ItemVenta() { }

        // Constructor que crea un item de venta con producto y cantidad
        public ItemVenta(Producto producto, int cantidad)
        {
            Producto = producto;
            Cantidad = cantidad;
            PrecioUnitario = producto.Precio;  // Guarda el precio al momento de la venta
        }
    }

    // Clase principal que representa una venta completa
    public class Venta
    {
        // Propiedades básicas de la venta
        public int NumeroVenta { get; set; }                    // Número único de la venta
        public DateTime Fecha { get; set; }                     // Fecha y hora de la venta
        public List<ItemVenta> Items { get; set; } = new List<ItemVenta>(); // Lista de productos vendidos
        public string NombreCajero { get; set; } = string.Empty; // Quien hizo la venta
        
        // Propiedades calculadas para los totales
        public decimal Subtotal => Items.Sum(i => i.Total);     // Suma de todos los items
        public decimal IVA => Subtotal * 0.19m;                 // 19% de IVA
        public decimal Total => Subtotal + IVA;                 // Total final con IVA

        // Constructor vacío
        public Venta() : this(0) { }

        // Constructor que inicializa una venta con número
        public Venta(int numeroVenta)
        {
            NumeroVenta = numeroVenta;
            Fecha = DateTime.Now;
        }

        // Agrega un producto a la venta
        public void AgregarProducto(Producto producto, int cantidad)
        {
            if (cantidad <= 0) return; // No agrega si la cantidad es 0 o negativa

            // Busca si el producto ya está en la venta
            var itemExistente = Items.FirstOrDefault(i => i.Producto.Id == producto.Id);
            if (itemExistente != null)
            {
                // Si ya existe, aumenta la cantidad
                itemExistente.Cantidad += cantidad;
            }
            else
            {
                Items.Add(new ItemVenta(producto, cantidad));
            }
        }

        // Quita una cantidad de un producto de la venta
        public void QuitarProducto(int productoId, int cantidad = 1)
        {
            var item = Items.FirstOrDefault(i => i.Producto.Id == productoId);
            if (item != null)
            {
                item.Cantidad -= cantidad;
                // Si la cantidad llega a 0 o menos, elimina el item completamente
                if (item.Cantidad <= 0)
                {
                    Items.Remove(item);
                }
            }
        }

        // Limpia todos los items de la venta (vacía el carrito)
        public void LimpiarCarrito()
        {
            Items.Clear();
        }

        public string GenerarRecibo()
        {
            var recibo = $@"
═══════════════════════════════════════
           🫓 AREPAS LA SABROSA 🫓
═══════════════════════════════════════

Factura #: {NumeroVenta:D6}
Fecha: {Fecha:dd/MM/yyyy HH:mm:ss}
Cajero: {NombreCajero}

───────────────────────────────────────
PRODUCTOS:
───────────────────────────────────────";

            foreach (var item in Items)
            {
                recibo += $@"
{item.Producto.Nombre}
  Cantidad: {item.Cantidad} x {item.PrecioUnitario:C}
  Total: {item.Total:C}";
            }

            recibo += $@"

───────────────────────────────────────
RESUMEN:
───────────────────────────────────────
Subtotal:        {Subtotal:C}
IVA (19%):       {IVA:C}
TOTAL:           {Total:C}

═══════════════════════════════════════
¡Gracias por su compra!
Vuelva pronto 🫓
═══════════════════════════════════════";

            return recibo;
        }
    }
}