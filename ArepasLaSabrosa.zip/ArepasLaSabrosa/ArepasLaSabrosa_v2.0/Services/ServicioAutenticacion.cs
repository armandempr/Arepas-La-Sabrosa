using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using ArepasLaSabrosa.Models;

namespace ArepasLaSabrosa.Services
{
    public static class ServicioAutenticacion
    {
        private static readonly List<Usuario> _usuarios = new()
        {
            new Usuario("admin", "admin123", RolUsuario.Admin),
            new Usuario("cajero", "cajero123", RolUsuario.Cajero),
            new Usuario("inventario", "inventario123", RolUsuario.UsuarioInventario),
            new Usuario("selfcheckout", "", RolUsuario.SelfCheckout) // Sin contraseña
        };

        private static Usuario? _usuarioActual;

        public static Usuario? UsuarioActual => _usuarioActual;

        public static bool IniciarSesion(string nombreUsuario, string password)
        {
            // Para self-checkout no se requiere contraseña
            if (nombreUsuario.ToLower() == "selfcheckout")
            {
                var usuarioSelfCheckout = _usuarios.FirstOrDefault(u => u.NombreUsuario.ToLower() == "selfcheckout");
                if (usuarioSelfCheckout != null && usuarioSelfCheckout.EstaActivo)
                {
                    _usuarioActual = usuarioSelfCheckout;
                    return true;
                }
                return false;
            }

            var usuario = _usuarios.FirstOrDefault(u => 
                u.NombreUsuario.Equals(nombreUsuario, StringComparison.OrdinalIgnoreCase) && 
                u.EstaActivo);

            if (usuario != null && usuario.VerificarPassword(password))
            {
                _usuarioActual = usuario;
                return true;
            }

            return false;
        }

        public static void CerrarSesion()
        {
            _usuarioActual = null;
        }

        public static bool TienePermiso(RolUsuario rolMinimo)
        {
            if (_usuarioActual?.EstaActivo != true) return false;
            return (int)_usuarioActual.Rol <= (int)rolMinimo;
        }

        // Permisos específicos por funcionalidad
        public static bool PuedeAccederVentas()
        {
            return _usuarioActual?.Rol is RolUsuario.Admin or RolUsuario.Cajero or RolUsuario.SelfCheckout;
        }

        public static bool PuedeGestionarInventario()
        {
            return _usuarioActual?.Rol is RolUsuario.Admin or RolUsuario.UsuarioInventario;
        }

        public static bool PuedeSoloVerInventario()
        {
            return _usuarioActual?.Rol == RolUsuario.Cajero;
        }

        public static bool PuedeVerEstadisticas()
        {
            return _usuarioActual?.Rol == RolUsuario.Admin;
        }

        public static bool PuedeGestionarUsuarios()
        {
            return _usuarioActual?.Rol == RolUsuario.Admin;
        }

        public static bool EsSelfCheckout()
        {
            return _usuarioActual?.Rol == RolUsuario.SelfCheckout;
        }

        public static bool CrearUsuario(string nombreUsuario, string password, RolUsuario rol)
        {
            if (!PuedeGestionarUsuarios()) return false;

            if (_usuarios.Any(u => u.NombreUsuario.Equals(nombreUsuario, StringComparison.OrdinalIgnoreCase)))
                return false;

            var nuevoUsuario = new Usuario(nombreUsuario, password, rol)
            {
                Id = _usuarios.Count > 0 ? _usuarios.Max(u => u.Id) + 1 : 1
            };

            _usuarios.Add(nuevoUsuario);
            return true;
        }

        public static ReadOnlyCollection<Usuario> ObtenerUsuarios()
        {
            return _usuarios.AsReadOnly();
        }
    }
}