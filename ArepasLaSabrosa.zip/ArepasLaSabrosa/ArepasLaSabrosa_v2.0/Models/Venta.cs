using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace ArepasLaSabrosa.Models
{
    public class ItemVenta : INotifyPropertyChanged
    {
        private int _cantidad;

        public Producto Producto { get; set; } = null!;
        
        public int Cantidad 
        { 
            get => _cantidad;
            set 
            {
                if (_cantidad != value)
                {
                    _cantidad = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(Total));
                }
            }
        }
        
        public decimal PrecioUnitario { get; set; }
        public decimal Total => Cantidad * PrecioUnitario;

        public event PropertyChangedEventHandler? PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public void NotifyPropertyChanged(string propertyName)
        {
            OnPropertyChanged(propertyName);
        }

        public ItemVenta() { }

        public ItemVenta(Producto producto, int cantidad)
        {
            Producto = producto;
            Cantidad = cantidad;
            PrecioUnitario = producto.Precio;
        }
    }

    public class Venta
    {
        public int NumeroVenta { get; set; }
        public DateTime Fecha { get; set; }
        public List<ItemVenta> Items { get; set; } = new List<ItemVenta>();
        public string NombreCajero { get; set; } = string.Empty;
        public decimal Subtotal => Items.Sum(i => i.Total);
        public decimal IVA => Subtotal * 0.19m; // 19% IVA
        public decimal Total => Subtotal + IVA;

        public Venta() : this(0) { }

        public Venta(int numeroVenta)
        {
            NumeroVenta = numeroVenta;
            Fecha = DateTime.Now;
        }

        public void AgregarProducto(Producto producto, int cantidad)
        {
            if (cantidad <= 0) return;

            var itemExistente = Items.FirstOrDefault(i => i.Producto.Id == producto.Id);
            if (itemExistente != null)
            {
                itemExistente.Cantidad += cantidad;
            }
            else
            {
                Items.Add(new ItemVenta(producto, cantidad));
            }
        }

        public void QuitarProducto(int productoId, int cantidad = 1)
        {
            var item = Items.FirstOrDefault(i => i.Producto.Id == productoId);
            if (item != null)
            {
                item.Cantidad -= cantidad;
                if (item.Cantidad <= 0)
                {
                    Items.Remove(item);
                }
            }
        }

        public void LimpiarCarrito()
        {
            Items.Clear();
        }

        public string GenerarRecibo()
        {
            var recibo = $@"
═══════════════════════════════════════
           🫓 AREPAS LA SABROSA 🫓
═══════════════════════════════════════

Factura #: {NumeroVenta:D6}
Fecha: {Fecha:dd/MM/yyyy HH:mm:ss}
Cajero: {NombreCajero}

───────────────────────────────────────
PRODUCTOS:
───────────────────────────────────────";

            foreach (var item in Items)
            {
                recibo += $@"
{item.Producto.Nombre}
  Cantidad: {item.Cantidad} x {item.PrecioUnitario:C}
  Total: {item.Total:C}";
            }

            recibo += $@"

───────────────────────────────────────
RESUMEN:
───────────────────────────────────────
Subtotal:        {Subtotal:C}
IVA (19%):       {IVA:C}
TOTAL:           {Total:C}

═══════════════════════════════════════
¡Gracias por su compra!
Vuelva pronto 🫓
═══════════════════════════════════════";

            return recibo;
        }
    }
}