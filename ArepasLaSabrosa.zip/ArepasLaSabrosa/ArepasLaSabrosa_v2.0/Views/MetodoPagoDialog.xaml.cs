using System;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace ArepasLaSabrosa.Views
{
    public partial class MetodoPagoDialog : Window
    {
        public string MetodoPago { get; private set; } = string.Empty;
        public decimal CantidadEntregada { get; private set; }
        public decimal Cambio { get; private set; }
        private decimal _totalPagar;

        public MetodoPagoDialog(decimal totalPagar)
        {
            InitializeComponent();
            _totalPagar = totalPagar;
            LblTotalPagar.Text = $"${totalPagar:N0}";
            CmbMetodoPago.SelectedIndex = 0; // Efectivo por defecto
        }

        private void CmbMetodoPago_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbMetodoPago.SelectedItem is ComboBoxItem item)
            {
                MetodoPago = item.Tag.ToString() ?? "";
                
                bool esEfectivo = MetodoPago == "Efectivo";
                PanelEfectivo.Visibility = esEfectivo ? Visibility.Visible : Visibility.Collapsed;
                PanelCambio.Visibility = Visibility.Collapsed;
                
                if (esEfectivo)
                {
                    TxtCantidadEntregada.Focus();
                    BtnConfirmar.IsEnabled = false;
                }
                else
                {
                    BtnConfirmar.IsEnabled = true;
                    CantidadEntregada = _totalPagar;
                    Cambio = 0;
                }
            }
        }

        private void TxtCantidadEntregada_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (decimal.TryParse(TxtCantidadEntregada.Text, out decimal cantidad))
            {
                CantidadEntregada = cantidad;
                Cambio = cantidad - _totalPagar;
                
                LblCambio.Text = $"${Cambio:N0}";
                
                if (Cambio >= 0)
                {
                    PanelCambio.Visibility = Visibility.Visible;
                    BtnConfirmar.IsEnabled = true;
                    
                    // Cambiar color según si hay cambio o es exacto
                    if (Cambio == 0)
                    {
                        LblCambio.Text = "Cantidad Exacta";
                        PanelCambio.Background = new System.Windows.Media.SolidColorBrush(
                            System.Windows.Media.Color.FromRgb(212, 237, 218)); // Verde claro
                    }
                    else
                    {
                        LblCambio.Text = $"${Cambio:N0}";
                        PanelCambio.Background = new System.Windows.Media.SolidColorBrush(
                            System.Windows.Media.Color.FromRgb(255, 243, 205)); // Amarillo claro
                    }
                }
                else
                {
                    PanelCambio.Visibility = Visibility.Collapsed;
                    BtnConfirmar.IsEnabled = false;
                }
            }
            else
            {
                PanelCambio.Visibility = Visibility.Collapsed;
                BtnConfirmar.IsEnabled = false;
                CantidadEntregada = 0;
                Cambio = 0;
            }
        }

        private void TxtCantidadEntregada_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Solo permitir números y punto decimal
            Regex regex = new Regex(@"^[0-9.]+$");
            e.Handled = !regex.IsMatch(e.Text);
        }

        private void BtnConfirmar_Click(object sender, RoutedEventArgs e)
        {
            if (MetodoPago == "Efectivo" && CantidadEntregada < _totalPagar)
            {
                MessageBox.Show("La cantidad entregada no puede ser menor al total a pagar.",
                    "Cantidad Insuficiente", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DialogResult = true;
            Close();
        }

        private void BtnCancelar_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}