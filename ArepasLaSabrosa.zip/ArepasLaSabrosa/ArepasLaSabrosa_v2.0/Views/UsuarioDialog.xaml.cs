using System;
using System.Windows;
using System.Windows.Controls;
using ArepasLaSabrosa.Models;
using ArepasLaSabrosa.Services;

namespace ArepasLaSabrosa.Views
{
    public partial class UsuarioDialog : Window
    {
        public UsuarioDialog()
        {
            InitializeComponent();
            CmbRol.SelectedIndex = 1; // Cajero por defecto
        }

        private void BtnCrear_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidarDatos())
                return;

            try
            {
                var nombreUsuario = TxtUsuario.Text.Trim();
                var password = TxtPassword.Password;
                var rolSeleccionado = ((ComboBoxItem)CmbRol.SelectedItem).Tag?.ToString() ?? "";
                
                if (!Enum.TryParse<RolUsuario>(rolSeleccionado, out var rol))
                {
                    MessageBox.Show("Seleccione un rol válido.", "Error", 
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                bool usuarioCreado = ServicioAutenticacion.CrearUsuario(nombreUsuario, password, rol);

                if (usuarioCreado)
                {
                    MessageBox.Show("Usuario creado exitosamente.", "Éxito", 
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    this.DialogResult = true;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("El nombre de usuario ya existe.", "Error", 
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    TxtUsuario.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al crear el usuario: {ex.Message}", "Error", 
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnCancelar_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }

        private bool ValidarDatos()
        {
            if (string.IsNullOrWhiteSpace(TxtUsuario.Text))
            {
                MessageBox.Show("Ingrese el nombre de usuario.", "Validación", 
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtUsuario.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(TxtPassword.Password))
            {
                MessageBox.Show("Ingrese la contraseña.", "Validación", 
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtPassword.Focus();
                return false;
            }

            if (TxtPassword.Password.Length < 3)
            {
                MessageBox.Show("La contraseña debe tener al menos 3 caracteres.", "Validación", 
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtPassword.Focus();
                return false;
            }

            if (CmbRol.SelectedItem == null)
            {
                MessageBox.Show("Seleccione un rol.", "Validación", 
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                CmbRol.Focus();
                return false;
            }

            return true;
        }
    }
}