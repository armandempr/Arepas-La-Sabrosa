using System;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using ArepasLaSabrosa.Models;

namespace ArepasLaSabrosa.Views
{
    public partial class CantidadDialog : Window
    {
        private readonly Producto _producto;
        public int Cantidad { get; private set; } = 1;

        public CantidadDialog(Producto producto)
        {
            InitializeComponent();
            _producto = producto;
            InicializarProducto();
            ActualizarTotal();
        }

        private void InicializarProducto()
        {
            LblProducto.Text = _producto.Nombre;
            LblPrecio.Text = $"${_producto.Precio:N0}";
            LblStockDisponible.Text = $"Stock disponible: {_producto.Stock}";
            TxtCantidad.Text = "1";
            
            // Validar estado inicial
            BtnMenos.IsEnabled = false;
            BtnMas.IsEnabled = _producto.Stock > 1;
            BtnAgregar.IsEnabled = _producto.Stock > 0;
        }

        private void ActualizarTotal()
        {
            // Evitar ejecución durante el proceso de carga de componentes
            if (TxtCantidad == null || LblTotal == null || BtnMenos == null || BtnMas == null || BtnAgregar == null || _producto == null)
            {
                return;
            }

            if (int.TryParse(TxtCantidad.Text, out int cantidad))
            {
                Cantidad = cantidad;
                var total = cantidad * _producto.Precio;
                LblTotal.Text = $"${total:N0}";

                // Actualizar estado de botones
                BtnMenos.IsEnabled = cantidad > 1;
                BtnMas.IsEnabled = cantidad < _producto.Stock;
                BtnAgregar.IsEnabled = cantidad > 0 && cantidad <= _producto.Stock;
            }
            else
            {
                LblTotal.Text = "$0";
                BtnAgregar.IsEnabled = false;
            }
        }

        private void BtnMenos_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(TxtCantidad.Text, out int cantidad) && cantidad > 1)
            {
                TxtCantidad.Text = (cantidad - 1).ToString();
            }
        }

        private void BtnMas_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(TxtCantidad.Text, out int cantidad) && cantidad < _producto.Stock)
            {
                TxtCantidad.Text = (cantidad + 1).ToString();
            }
        }

        private void TxtCantidad_TextChanged(object sender, TextChangedEventArgs e)
        {
            ActualizarTotal();
        }

        private void TxtCantidad_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Solo permitir números enteros
            Regex regex = new Regex(@"^[0-9]+$");
            e.Handled = !regex.IsMatch(e.Text);
        }

        private void BtnAgregar_Click(object sender, RoutedEventArgs e)
        {
            if (!int.TryParse(TxtCantidad.Text, out int cantidad) || cantidad <= 0)
            {
                MessageBox.Show("Ingrese una cantidad válida.", "Cantidad Inválida", 
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (cantidad > _producto.Stock)
            {
                MessageBox.Show($"La cantidad solicitada ({cantidad}) excede el stock disponible ({_producto.Stock}).",
                    "Stock Insuficiente", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            Cantidad = cantidad;
            DialogResult = true;
            Close();
        }

        private void BtnCancelar_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}